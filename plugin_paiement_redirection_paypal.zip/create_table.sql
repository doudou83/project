CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(255),
    item_price FLOAT(10,2),
    payer_email VARCHAR(255),
    card_number VARCHAR(255),
    expiry_date VARCHAR(10),
    payment_status VARCHAR(50),
    created DATETIME,
    modified DATETIME
);
