<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'plugin_paiement');
define('DB_USER', 'root');
define('DB_PASS', '');

define('PAYPAL_CLIENT_ID', 'VOTRE_CLIENT_ID');
define('PAYPAL_SECRET', 'VOTRE_SECRET');
?>
