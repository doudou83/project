<?php
require 'config.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

// --- Connexion DB
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur DB : " . $e->getMessage());
}

// --- Récupération du formulaire
$card_number = $_POST['card-number'] ?? '';
$expiry_date = $_POST['expiry-date'] ?? '';
$email = $_POST['email'] ?? '';
$item_name = $_POST['item_name'] ?? '';
$amount = $_POST['amount'] ?? '';

// --- Fonctions de validation
function validateCardNumber($number) {
    return preg_match('/^[0-9]{16}$/', $number);
}
function validateExpiryDate($date) {
    return preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $date);
}
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

if (!validateCardNumber($card_number) || !validateExpiryDate($expiry_date) || !validateEmail($email)) {
    exit("Données invalides.");
}

// --- Hasher la carte
$hashed_card = password_hash($card_number, PASSWORD_DEFAULT);

// --- Enregistrement
try {
    $sql = "INSERT INTO transactions (item_name, item_price, payer_email, card_number, expiry_date, payment_status, created, modified)
            VALUES (?, ?, ?, ?, ?, 'en attente', NOW(), NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$item_name, $amount, $email, $hashed_card, $expiry_date]);
} catch (PDOException $e) {
    exit("Erreur SQL : " . $e->getMessage());
}

// --- Création de la transaction PayPal
$paypal_url = "https://api.sandbox.paypal.com/v1/payments/payment";
$client_id = PAYPAL_CLIENT_ID;
$secret = PAYPAL_SECRET;

// Obtenir le token
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.sandbox.paypal.com/v1/oauth2/token");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Accept: application/json",
    "Accept-Language: en_US"
]);
curl_setopt($ch, CURLOPT_USERPWD, "$client_id:$secret");
curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
$result = curl_exec($ch);
curl_close($ch);
$token = json_decode($result, true)['access_token'] ?? null;

if (!$token) {
    exit("Échec de l'obtention du token PayPal.");
}

// Créer le paiement PayPal
$data = json_encode([
    "intent" => "sale",
    "payer" => [ "payment_method" => "paypal" ],
    "transactions" => [[
        "amount" => [
            "total" => $amount,
            "currency" => "EUR"
        ],
        "description" => "Paiement pour $item_name"
    ]],
    "redirect_urls" => [
        "return_url" => "http://localhost/success.php",
        "cancel_url" => "http://localhost/cancel.php"
    ]
]);

$ch = curl_init($paypal_url);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer $token"
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$payment = json_decode($response, true);
$approval_url = null;
foreach ($payment['links'] as $link) {
    if ($link['rel'] === 'approval_url') {
        $approval_url = $link['href'];
        break;
    }
}

if ($approval_url) {
    header("Location: $approval_url");
    exit;
} else {
    echo "Erreur PayPal : lien non reçu.";
}
?>
