<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Formulaire de paiement</title>
  <style>
    body { font-family: Arial; background-color: #f4f4f4; padding: 20px; }
    .form-box {
      background: #fff; padding: 20px; border-radius: 10px; max-width: 400px; margin: auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    label { display: block; margin-top: 15px; }
    input[type="text"], input[type="email"] {
      width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;
    }
  </style>
</head>
<body>

  <div class="form-box">
    <h2>Paiement par carte</h2>
    <form id="payment-form" method="post" action="traitement.php">
      <label for="card-number">Numéro de carte :</label>
      <input type="text" id="card-number" name="card-number" required>

      <label for="expiry-date">Date d'expiration :</label>
      <input type="text" id="expiry-date" name="expiry-date" placeholder="MM/AA" required>

      <label for="email">Email :</label>
      <input type="email" id="email" name="email" required>

      <input type="hidden" name="item_name" value="Réseau Informatique">
      <input type="hidden" name="amount" value="10.00">
      <br>
      <button type="submit">Valider et enregistrer</button>
    </form>
  </div>
</body>
</html>
